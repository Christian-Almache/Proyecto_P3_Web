/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.controller;

import com.espe.test.dao.CategoriaDAO;
import com.espe.test.model.Categoria;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/categorias")
public class CategoriaController extends HttpServlet {

    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null || action.isBlank()) action = "list";

        try {
            switch (action) {
                case "new" -> showForm(req, resp, new Categoria(), "create");
                case "edit" -> showEdit(req, resp);
                case "delete" -> doDeleteById(req, resp);
                default -> doList(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error DB", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "";

        try {
            switch (action) {
                case "create" -> doCreate(req, resp);
                case "update" -> doUpdate(req, resp);
                default -> resp.sendRedirect(req.getContextPath() + "/categorias");
            }
        } catch (Exception e) {
            throw new ServletException("Error DB", e);
        }
    }

    private void doList(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {

        List<Categoria> categorias = categoriaDAO.findAll();
        req.setAttribute("categorias", categorias);
        req.getRequestDispatcher("/WEB-INF/categoria-list.jsp").forward(req, resp);
    }

    private void showEdit(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {

        String idStr = req.getParameter("id");

        if (idStr == null || idStr.isBlank()) {
            throw new ServletException("ID de categoría no recibido");
        }

        long id = Long.parseLong(idStr);

        Categoria categoria = categoriaDAO.findById(id);

        if (categoria == null) {
            resp.sendRedirect(req.getContextPath() + "/categorias");
            return;
        }

        showForm(req, resp, categoria, "update");
    }
    
    private void showForm(HttpServletRequest req, HttpServletResponse resp,
                          Categoria categoria, String action)
            throws ServletException, IOException {

        req.setAttribute("categoria", categoria);
        req.setAttribute("action", action);
        req.getRequestDispatcher("/WEB-INF/categoria-form.jsp").forward(req, resp);
    }

    private void doCreate(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException, SQLException {

        Categoria categoria = parseCategoria(req, false);
        categoriaDAO.create(categoria);
        resp.sendRedirect(req.getContextPath() + "/categorias");
    }

    private void doUpdate(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException, SQLException {

        Categoria categoria = parseCategoria(req, true);
        categoriaDAO.update(categoria);
        resp.sendRedirect(req.getContextPath() + "/categorias");
    }

    private void doDeleteById(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, SQLException {

        String idStr = req.getParameter("id");

        if (idStr == null || idStr.isBlank()) {
            throw new IOException("ID de categoría no recibido");
        }

        long id = Long.parseLong(idStr);

        categoriaDAO.delete(id);
        resp.sendRedirect(req.getContextPath() + "/categorias");
    }

    private Categoria parseCategoria(HttpServletRequest req, boolean withId)
            throws ServletException {

        try {
            String nombre = req.getParameter("nombre_categoria");

            if (nombre == null || nombre.isBlank())
                throw new ServletException("Nombre de categoría requerido");

            Categoria categoria = new Categoria(
                    null,
                    nombre.trim(),
                    true
            );

            if (withId) {
                String idStr = req.getParameter("id_categoria");

                if (idStr == null || idStr.isBlank()) {
                    throw new ServletException("ID de categoría requerido");
                }

                categoria.setId_categoria(Long.parseLong(idStr));
            }


            return categoria;

        } catch (NumberFormatException e) {
            throw new ServletException("Datos inválidos", e);
        }
    }
}
