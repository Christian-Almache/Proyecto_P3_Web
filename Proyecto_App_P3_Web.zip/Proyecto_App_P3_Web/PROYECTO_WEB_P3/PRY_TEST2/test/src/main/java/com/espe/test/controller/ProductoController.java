/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package com.espe.test.controller;

import com.espe.test.dao.CategoriaDAO;
import com.espe.test.dao.ProductoDAO;
import com.espe.test.dao.ProveedorDAO;
import com.espe.test.model.Producto;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/productos")
public class ProductoController extends HttpServlet {

    private final ProductoDAO productoDAO = new ProductoDAO();
    private final CategoriaDAO categoriaDAO = new CategoriaDAO();
    private final ProveedorDAO proveedorDAO = new ProveedorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null || action.isBlank()) action = "list";

        try {
            switch (action) {
                case "new" -> showForm(req, resp, new Producto(), "create");
                case "edit" -> showEdit(req, resp);
                case "delete" -> doDeleteById(req, resp);
                default -> doList(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error DB", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null || action.isBlank()) {
            action = "create";
        }
        try {
            switch (action) {
                case "create" -> doCreate(req, resp);
                case "update" -> doUpdate(req, resp);
                default -> resp.sendRedirect(req.getContextPath() + "/productos");
            }
        } catch (Exception e) {
            throw new ServletException("Error DB", e);
        }
    }

    private void doList(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {

        List<Producto> productos = productoDAO.findAll();
        req.setAttribute("productos", productos);
        req.getRequestDispatcher("/WEB-INF/producto-list.jsp")
                .forward(req, resp);
    }

    private void showEdit(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {

        long id = Long.parseLong(req.getParameter("id"));
        Producto producto = productoDAO.findById(id);

        if (producto == null) {
            resp.sendRedirect(req.getContextPath() + "/productos");
            return;
        }

        showForm(req, resp, producto, "update");
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp,
                          Producto producto, String action)
            throws ServletException, IOException, SQLException {

        req.setAttribute("producto", producto);
        req.setAttribute("action", action);

        req.setAttribute("categorias", categoriaDAO.findAll());
        req.setAttribute("proveedores", proveedorDAO.findAll());

        req.getRequestDispatcher("/WEB-INF/producto-form.jsp")
                .forward(req, resp);
    }

    private void doCreate(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException, SQLException {

        Producto producto = parseProducto(req, false);
        productoDAO.create(producto);
        resp.sendRedirect(req.getContextPath() + "/productos");
    }

    private void doUpdate(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException, SQLException {

        Producto producto = parseProducto(req, true);
        productoDAO.update(producto);
        resp.sendRedirect(req.getContextPath() + "/productos");
    }

    private void doDeleteById(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, SQLException {

        long id = Long.parseLong(req.getParameter("id"));
        productoDAO.delete(id);
        resp.sendRedirect(req.getContextPath() + "/productos");
    }

    private Producto parseProducto(HttpServletRequest req, boolean withId)
        throws ServletException {
        try {
            String nombre = req.getParameter("nombre_producto");
            String precioStr = req.getParameter("precio");

            if (nombre == null || nombre.isBlank())
                throw new ServletException("Nombre requerido");

            if (precioStr == null || precioStr.isBlank())
                throw new ServletException("Precio requerido");

            BigDecimal precio;
            try {
                precio = new BigDecimal(precioStr);
            } catch (NumberFormatException e) {
                throw new ServletException("Precio inválido");
            }

            if (precio.compareTo(BigDecimal.ZERO) < 0)
                throw new ServletException("Precio inválido");

            // CATEGORIA
            String catId = req.getParameter("id_categoria_producto");
            String provId = req.getParameter("id_proveedor_producto");

            if (catId == null || catId.isBlank()) {
                throw new ServletException("Debe seleccionar una categoría");
            }

            if (provId == null || provId.isBlank()) {
                throw new ServletException("Debe seleccionar un proveedor");
            }

            // 👉 NO conviertas a long
            Producto producto = new Producto(
                    null,
                    nombre.trim(),
                    precio,
                    catId,     // STRING
                    provId,    // STRING
                    true
            );


            if (withId) {
                String idProductoStr = req.getParameter("id_producto");
                if (idProductoStr == null || idProductoStr.isBlank()) {
                    throw new ServletException("ID de producto inválido");
                }
                producto.setId_producto(Long.parseLong(idProductoStr));
            }

            return producto;

        } catch (ServletException e) {
            throw e;
        } catch (Exception e) {
            throw new ServletException("Datos inválidos", e);
        }
    }
    

}
