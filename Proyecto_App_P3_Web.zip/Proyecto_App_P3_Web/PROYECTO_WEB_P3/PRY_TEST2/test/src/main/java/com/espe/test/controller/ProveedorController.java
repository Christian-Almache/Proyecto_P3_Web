/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.controller;

import com.espe.test.dao.ProveedorDAO;
import com.espe.test.model.Proveedor;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/proveedores")
public class ProveedorController extends HttpServlet {

    private final ProveedorDAO proveedorDAO = new ProveedorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null || action.isBlank()) action = "list";

        try {
            switch (action) {
                case "new" -> showForm(req, resp, new Proveedor(), "create");
                case "edit" -> showEdit(req, resp);
                case "delete" -> doDeleteById(req, resp);
                default -> doList(req, resp);
            }
        } catch (Exception e) {
            throw new ServletException("Error DB", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "";

        try {
            switch (action) {
                case "create" -> doCreate(req, resp);
                case "update" -> doUpdate(req, resp);
                default -> resp.sendRedirect(req.getContextPath() + "/proveedores");
            }
        } catch (Exception e) {
            throw new ServletException("Error DB", e);
        }
    }


    private void doList(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {

        List<Proveedor> proveedores = proveedorDAO.findAll();
        req.setAttribute("proveedores", proveedores);
        req.getRequestDispatcher("/WEB-INF/proveedor-list.jsp")
           .forward(req, resp);
    }

    private void showEdit(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {

        long id = Long.parseLong(req.getParameter("id"));
        Proveedor proveedor = proveedorDAO.findById(id);

        if (proveedor == null) {
            resp.sendRedirect(req.getContextPath() + "/proveedores");
            return;
        }

        showForm(req, resp, proveedor, "update");
    }

    private void showForm(HttpServletRequest req, HttpServletResponse resp,
                          Proveedor proveedor, String action)
            throws ServletException, IOException {

        req.setAttribute("proveedor", proveedor);
        req.setAttribute("action", action);
        req.getRequestDispatcher("/WEB-INF/proveedor-form.jsp")
           .forward(req, resp);
    }

    private void doCreate(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException, SQLException {

        Proveedor proveedor = parseProveedor(req, false);
        proveedorDAO.create(proveedor);
        resp.sendRedirect(req.getContextPath() + "/proveedores");
    }

    private void doUpdate(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException, SQLException {

        Proveedor proveedor = parseProveedor(req, true);
        proveedorDAO.update(proveedor);
        resp.sendRedirect(req.getContextPath() + "/proveedores");
    }

    private void doDeleteById(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, SQLException {

        long id = Long.parseLong(req.getParameter("id"));
        proveedorDAO.delete(id); // cambia estado
        resp.sendRedirect(req.getContextPath() + "/proveedores");
    }


    private Proveedor parseProveedor(HttpServletRequest req, boolean withId)
            throws ServletException {

        try {
            String nombre = req.getParameter("nombre_proveedor");
            String telefono = req.getParameter("telefono_proveedor");

            if (nombre == null || nombre.isBlank())
                throw new ServletException("Nombre requerido");

            if (telefono == null || telefono.isBlank())
                throw new ServletException("Teléfono requerido");

            Proveedor proveedor = new Proveedor(
                    null,
                    nombre.trim(),
                    telefono.trim(),
                    true
            );

            if (withId) {
                proveedor.setId_proveedor(
                        Long.parseLong(req.getParameter("id_proveedor"))
                );
            }

            return proveedor;

        } catch (NumberFormatException e) {
            throw new ServletException("Datos inválidos", e);
        }
    }
}
