/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.dao;

import com.espe.test.model.Categoria;
import com.espe.test.utils.Db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    public List<Categoria> findAll() throws SQLException {
        String sql = """
                     SELECT id_categoria, nombre_categoria, estado_categoria
                             FROM categoria
                             WHERE estado_categoria = 1
                             ORDER BY id_categoria DESC""";

        List<Categoria> categorias = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Categoria cat = new Categoria();
                cat.setId_categoria(rs.getLong("id_categoria"));
                cat.setNombre_categoria(rs.getString("nombre_categoria"));
                cat.setEstado_categoria(rs.getBoolean("estado_categoria"));
                categorias.add(cat);
            }
            return categorias;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }

    public Categoria findById(long id) throws SQLException {
        String sql = "SELECT id_categoria, nombre_categoria, estado_categoria "
                   + "FROM categoria WHERE id_categoria = ?;";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);

            ResultSet rs = ps.executeQuery();
            if (!rs.next())
                return null;

            return new Categoria(
                    rs.getLong("id_categoria"),
                    rs.getString("nombre_categoria"),
                    rs.getBoolean("estado_categoria")
            );

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }

    public long create(Categoria categoria) throws SQLException {
        String sql = "INSERT INTO categoria (nombre_categoria, estado_categoria) "
                   + "VALUES (?, ?);";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, categoria.getNombre_categoria());
            ps.setBoolean(2, categoria.isEstado_categoria());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                return rs.getLong(1);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
        return 0;
    }

    public boolean update(Categoria categoria) throws SQLException {
        String sql = "UPDATE categoria SET nombre_categoria = ?, estado_categoria = ? "
                   + "WHERE id_categoria = ?;";

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql);

            ps.setString(1, categoria.getNombre_categoria());
            ps.setBoolean(2, categoria.isEstado_categoria());
            ps.setLong(3, categoria.getId_categoria());

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }

    // DELETE LÓGICO
    public boolean delete(long id) throws SQLException {
        
        String sqlCategoria =
            "UPDATE categoria " +
            "SET estado_categoria = 0 " +
            "WHERE id_categoria = ?";
        
        String sqlProducto =
            "UPDATE producto " +
            "SET id_categoria_producto = NULL " +
            "WHERE id_categoria_producto = ?";

        Connection conn = null;
        PreparedStatement psProd = null;
        PreparedStatement psCat = null;

        try {
            conn = Db.getConnection();
            conn.setAutoCommit(false);

            psProd = conn.prepareStatement(sqlProducto);
            psProd.setLong(1, id);
            psProd.executeUpdate();

            psCat = conn.prepareStatement(sqlCategoria);
            psCat.setLong(1, id);
            int rows = psCat.executeUpdate();

            conn.commit();
            return rows == 1;

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw new RuntimeException(e);

        } finally {
            Db.closeConnection(conn);
        }
    }
    public String findNombreById(long id) {
        String sql = "SELECT nombre_categoria FROM categoria WHERE id_categoria = ?";
        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("nombre_categoria");
            }
            return "Ninguno";

        } catch (SQLException e) {
            throw new RuntimeException(e);
    }
}


}
