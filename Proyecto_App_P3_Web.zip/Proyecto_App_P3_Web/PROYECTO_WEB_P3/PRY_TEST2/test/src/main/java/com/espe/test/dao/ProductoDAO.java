/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.dao;

import com.espe.test.model.Producto;
import com.espe.test.utils.Db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    public List<Producto> findAll() {
        String sql = """
            SELECT id_producto, nombre_producto, precio,
                   id_categoria_producto, id_proveedor_producto
            FROM producto
            WHERE estado_producto = 1
        """;

        List<Producto> productos = new ArrayList<>();

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            CategoriaDAO categoriaDAO = new CategoriaDAO();
            ProveedorDAO proveedorDAO = new ProveedorDAO();

            while (rs.next()) {
                Producto p = new Producto();

                p.setId_producto(rs.getLong("id_producto"));
                p.setNombre_producto(rs.getString("nombre_producto"));
                p.setPrecio(rs.getBigDecimal("precio"));

                long idCategoria = rs.getLong("id_categoria_producto");
                long idProveedor = rs.getLong("id_proveedor_producto");

                // 🔥 AQUÍ está la magia
                String nombreCategoria = categoriaDAO.findNombreById(idCategoria);
                String nombreProveedor = proveedorDAO.findNombreById(idProveedor);

                // Guardas como STRING (no IDs)
                p.setId_categoria_producto(nombreCategoria);
                p.setId_proveedor_producto(nombreProveedor);

                productos.add(p);
            }

            return productos;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }



    public Producto findById(long id) throws SQLException {
        String sql = "SELECT id_producto, nombre_producto, precio, "
                + "id_categoria_producto, id_proveedor_producto, estado_producto "
                + "FROM producto WHERE id_producto = ?;";

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();

            if (!rs.next()) return null;

            return new Producto(
                    rs.getLong("id_producto"),
                    rs.getString("nombre_producto"),
                    rs.getBigDecimal("precio"),
                    // BD NUMÉRICA → STRING
                    String.valueOf(rs.getLong("id_categoria_producto")),
                    String.valueOf(rs.getLong("id_proveedor_producto")),
                    rs.getBoolean("estado_producto")
            );
        }
    }

    public long create(Producto producto) throws SQLException {
        String sql = "INSERT INTO producto "
                + "(nombre_producto, precio, id_categoria_producto, id_proveedor_producto, estado_producto) "
                + "VALUES (?,?,?,?,?);";

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, producto.getNombre_producto());
            ps.setBigDecimal(2, producto.getPrecio());

            // OBJETO STRING → BD NUMÉRICA (JDBC lo convierte)
            ps.setString(3, producto.getId_categoria_producto());
            ps.setString(4, producto.getId_proveedor_producto());

            ps.setBoolean(5, producto.isEstado_producto());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            return rs.next() ? rs.getLong(1) : 0;
        }
    }

    public boolean update(Producto producto) throws SQLException {
        String sql = "UPDATE producto SET nombre_producto = ?, precio = ?, "
                + "id_categoria_producto = ?, id_proveedor_producto = ?, estado_producto = ? "
                + "WHERE id_producto = ?;";

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, producto.getNombre_producto());
            ps.setBigDecimal(2, producto.getPrecio());

            // OBJETO STRING → BD NUMÉRICA
            ps.setString(3, producto.getId_categoria_producto());
            ps.setString(4, producto.getId_proveedor_producto());

            ps.setBoolean(5, producto.isEstado_producto());
            ps.setLong(6, producto.getId_producto());

            return ps.executeUpdate() == 1;
        }
    }

    // DELETE LÓGICO
    public boolean delete(long id) throws SQLException {
        String sql = "UPDATE producto SET estado_producto = 0 WHERE id_producto = ?;";

        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            return ps.executeUpdate() == 1;
        }
    }
}
