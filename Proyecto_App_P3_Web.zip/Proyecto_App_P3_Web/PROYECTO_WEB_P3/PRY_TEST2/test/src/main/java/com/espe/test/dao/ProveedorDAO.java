/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.dao;

import com.espe.test.model.Proveedor;
import com.espe.test.utils.Db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProveedorDAO {

    public List<Proveedor> findAll() throws SQLException {
        String sql = """
                     SELECT id_proveedor, nombre_proveedor, telefono_proveedor, estado_proveedor
                     FROM proveedor
                     WHERE estado_proveedor = 1
                     ORDER BY id_proveedor DESC
                     """;

        List<Proveedor> proveedores = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Proveedor p = new Proveedor();
                p.setId_proveedor(rs.getLong("id_proveedor"));
                p.setNombre_proveedor(rs.getString("nombre_proveedor"));
                p.setTelefono_proveedor(rs.getString("telefono_proveedor"));
                p.setEstado_proveedor(rs.getBoolean("estado_proveedor"));
                proveedores.add(p);
            }

            return proveedores;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }

    public Proveedor findById(long id) throws SQLException {
        String sql = """
                     SELECT id_proveedor, nombre_proveedor, telefono_proveedor, estado_proveedor
                     FROM proveedor
                     WHERE id_proveedor = ?
                     """;

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);

            ResultSet rs = ps.executeQuery();
            if (!rs.next())
                return null;

            return new Proveedor(
                    rs.getLong("id_proveedor"),
                    rs.getString("nombre_proveedor"),
                    rs.getString("telefono_proveedor"),
                    rs.getBoolean("estado_proveedor")
            );

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }

    public long create(Proveedor proveedor) throws SQLException {
        String sql = """
                     INSERT INTO proveedor (nombre_proveedor, telefono_proveedor, estado_proveedor)
                     VALUES (?, ?, ?)
                     """;

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

            ps.setString(1, proveedor.getNombre_proveedor());
            ps.setString(2, proveedor.getTelefono_proveedor());
            ps.setBoolean(3, proveedor.isEstado_proveedor());

            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                return rs.getLong(1);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }

        return 0;
    }

    public boolean update(Proveedor proveedor) throws SQLException {
        String sql = """
                     UPDATE proveedor
                     SET nombre_proveedor = ?, telefono_proveedor = ?, estado_proveedor = ?
                     WHERE id_proveedor = ?
                     """;

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = Db.getConnection();
            ps = conn.prepareStatement(sql);

            ps.setString(1, proveedor.getNombre_proveedor());
            ps.setString(2, proveedor.getTelefono_proveedor());
            ps.setBoolean(3, proveedor.isEstado_proveedor());
            ps.setLong(4, proveedor.getId_proveedor());

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }

    // DELETE LÓGICO + ACTUALIZA PRODUCTOS
    public boolean delete(long id) throws SQLException {

        String sqlProducto =
            "UPDATE producto SET id_proveedor_producto = NULL WHERE id_proveedor_producto = ?";

        String sqlProveedor =
            "UPDATE proveedor SET estado_proveedor = 0 WHERE id_proveedor = ?";

        Connection conn = null;
        PreparedStatement psProd = null;
        PreparedStatement psProv = null;

        try {
            conn = Db.getConnection();
            conn.setAutoCommit(false);

            psProd = conn.prepareStatement(sqlProducto);
            psProd.setLong(1, id);
            psProd.executeUpdate();

            psProv = conn.prepareStatement(sqlProveedor);
            psProv.setLong(1, id);
            int rows = psProv.executeUpdate();

            conn.commit();
            return rows == 1;

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw new RuntimeException(e);
        } finally {
            Db.closeConnection(conn);
        }
    }
    public String findNombreById(long id) {
        String sql = "SELECT nombre_proveedor FROM proveedor WHERE id_proveedor = ?";
        try (Connection conn = Db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("nombre_proveedor");
            }
            return "Ninguno";

        } catch (SQLException e) {
            throw new RuntimeException(e);
    }
}

}
