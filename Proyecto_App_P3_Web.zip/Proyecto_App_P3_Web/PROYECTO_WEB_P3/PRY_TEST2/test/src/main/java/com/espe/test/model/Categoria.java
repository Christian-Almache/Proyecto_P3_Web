/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.model;

/**
 *
 * @author christian
 */
public class Categoria {
    private Long id_categoria;
    private String nombre_categoria;
    private boolean estado_categoria;
    
    public Categoria(){
        
    }
    
    public Categoria(Long id_categoria,String nombre_categoria,boolean estado_categoria){
        this.id_categoria=id_categoria;
        this.nombre_categoria=nombre_categoria;
        this.estado_categoria=estado_categoria;
    }

    /**
     * @return the id_categoria
     */
    public Long getId_categoria() {
        return id_categoria;
    }

    /**
     * @param id_categoria the id_categoria to set
     */
    public void setId_categoria(Long id_categoria) {
        this.id_categoria = id_categoria;
    }

    /**
     * @return the nombre_categoria
     */
    public String getNombre_categoria() {
        return nombre_categoria;
    }

    /**
     * @param nombre_categoria the nombre_categoria to set
     */
    public void setNombre_categoria(String nombre_categoria) {
        this.nombre_categoria = nombre_categoria;
    }

    /**
     * @return the estado_categoria
     */
    public boolean isEstado_categoria() {
        return estado_categoria;
    }

    /**
     * @param estado_categoria the estado_categoria to set
     */
    public void setEstado_categoria(boolean estado_categoria) {
        this.estado_categoria = estado_categoria;
    }
    
    


}
