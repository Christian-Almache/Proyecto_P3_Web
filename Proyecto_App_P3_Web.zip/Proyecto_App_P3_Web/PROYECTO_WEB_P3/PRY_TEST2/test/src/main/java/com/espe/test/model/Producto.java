/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.model;

import java.math.BigDecimal;

/**
 *
 * @author christian
 */
public class Producto {
    private Long id_producto;
    private String nombre_producto;
    private BigDecimal precio;
    private String nombre_categoria_producto;
    private String nombre_proveedor_producto;
    private boolean estado_producto;
    
    public Producto() {
    }
    
    public Producto(Long id_producto, String nombre_producto, BigDecimal precio,
                    String id_categoria_producto, String id_proveedor_producto, boolean estado_producto) {
        
        this.id_producto = id_producto;
        this.nombre_producto = nombre_producto;
        this.precio = precio;
        this.nombre_categoria_producto = id_categoria_producto;
        this.nombre_proveedor_producto = id_proveedor_producto;
        this.estado_producto = estado_producto;
    }

    /**
     * @return the id_producto
     */
    public Long getId_producto() {
        return id_producto;
    }

    /**
     * @param id_producto the id_producto to set
     */
    public void setId_producto(Long id_producto) {
        this.id_producto = id_producto;
    }

    /**
     * @return the nombre_producto
     */
    public String getNombre_producto() {
        return nombre_producto;
    }

    /**
     * @param nombre_producto the nombre_producto to set
     */
    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    /**
     * @return the precio
     */
    public BigDecimal getPrecio() {
        return precio;
    }

    /**
     * @param precio the precio to set
     */
    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    /**
     * @return the id_categoria_producto
     */
    public String getId_categoria_producto() {
        return nombre_categoria_producto;
    }

    /**
     * @param id_categoria_producto the id_categoria_producto to set
     */
    public void setId_categoria_producto(String id_categoria_producto) {
        this.nombre_categoria_producto = id_categoria_producto;
    }

    /**
     * @return the id_proveedor_producto
     */
    public String getId_proveedor_producto() {
        return nombre_proveedor_producto;
    }

    /**
     * @param id_proveedor_producto the id_proveedor_producto to set
     */
    public void setId_proveedor_producto(String id_proveedor_producto) {
        this.nombre_proveedor_producto = id_proveedor_producto;
    }

    /**
     * @return the estado_producto
     */
    public boolean isEstado_producto() {
        return estado_producto;
    }

    /**
     * @param estado_producto the estado_producto to set
     */
    public void setEstado_producto(boolean estado_producto) {
        this.estado_producto = estado_producto;
    }
    
    
    
    
    
}
