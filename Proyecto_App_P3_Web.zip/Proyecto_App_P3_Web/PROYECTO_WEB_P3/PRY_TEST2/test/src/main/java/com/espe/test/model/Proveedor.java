/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.espe.test.model;

/**
 *
 * @author christian
 */
public class Proveedor {
    private Long id_proveedor;
    private String nombre_proveedor;
    private String telefono_proveedor;
    private boolean estado_proveedor;
    
    public Proveedor(){
        
    }
    
    public Proveedor(Long id_proveedor,String nombre_proveedor,String telefono_proveedor,
                    boolean estado_proveedor){
        this.id_proveedor=id_proveedor;
        this.nombre_proveedor=nombre_proveedor;
        this.telefono_proveedor=telefono_proveedor;
        this.estado_proveedor=estado_proveedor;
    }

    /**
     * @return the id_proveedor
     */
    public Long getId_proveedor() {
        return id_proveedor;
    }

    /**
     * @param id_proveedor the id_proveedor to set
     */
    public void setId_proveedor(Long id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    /**
     * @return the nombre_proveedor
     */
    public String getNombre_proveedor() {
        return nombre_proveedor;
    }

    /**
     * @param nombre_proveedor the nombre_proveedor to set
     */
    public void setNombre_proveedor(String nombre_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
    }

    /**
     * @return the telefono_proveedor
     */
    public String getTelefono_proveedor() {
        return telefono_proveedor;
    }

    /**
     * @param telefono_proveedor the telefono_proveedor to set
     */
    public void setTelefono_proveedor(String telefono_proveedor) {
        this.telefono_proveedor = telefono_proveedor;
    }

    /**
     * @return the estado_proveedor
     */
    public boolean isEstado_proveedor() {
        return estado_proveedor;
    }

    /**
     * @param estado_proveedor the estado_proveedor to set
     */
    public void setEstado_proveedor(boolean estado_proveedor) {
        this.estado_proveedor = estado_proveedor;
    }

    
}
