package com.espe.test.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Db {

    private static final String URL =
        "jdbc:mysql://localhost:3306/almacen"
        + "?useSSL=false"
        + "&allowPublicKeyRetrieval=true"
        + "&serverTimezone=UTC";

    private static final String USER = "wb_user";
    private static final String PASS = "WbPassword123!";

    private Db() {
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
    public static void closeConnection(Connection conn) throws SQLException {
        if (conn != null) {             
            if (!conn.isClosed()) {  
                conn.close();        
            }

        }
    }
}

